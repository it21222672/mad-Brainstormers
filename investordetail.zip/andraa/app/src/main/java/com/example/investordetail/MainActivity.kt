package com.example.investordetail

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {


    private lateinit var insertbtton: Button
    private lateinit var fetchbtton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        insertbtton = findViewById(R.id.insertbtton)
        fetchbtton = findViewById(R.id.fetchbtton)

        insertbtton.setOnClickListener{
            val intent = Intent(this , forminvestor::class.java)
            startActivity(intent)
        }
    }
}