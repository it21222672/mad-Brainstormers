package com.example.mainactivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class interface2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_interface2)


        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        supportActionBar?.hide()


        val bttn4 = findViewById<Button>(R.id.bttn4);

        bttn4.setOnClickListener(){
            val intenta = Intent(this, interface3::class.java)
            startActivity(intenta)
            finish()
        }



        val bsines1 = findViewById<Button>(R.id.bsines1);
        bsines1.setOnClickListener(){
            val intenta = Intent(this, buybsiness::class.java)
            startActivity(intenta)
            finish()
        }

        val bsines2 = findViewById<Button>(R.id.bsines2);
        bsines2.setOnClickListener(){
            val intenta = Intent(this, buybsiness::class.java)
            startActivity(intenta)
            finish()
        }
        val bsines3 = findViewById<Button>(R.id.bsines3);
        bsines3.setOnClickListener(){
            val intenta = Intent(this, buybsiness::class.java)
            startActivity(intenta)
            finish()
        }


    }
}