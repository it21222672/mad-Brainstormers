package com.example.mainactivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        supportActionBar?.hide()

        val submit = findViewById<Button>(R.id.btton1)


        submit.setOnClickListener(){
            val intenta = Intent(this, interface1::class.java)
            startActivity(intenta)
            finish()
        }

        //handle the button

        val name = findViewById<EditText>(R.id.edittxt1)
        val nic = findViewById<EditText>(R.id.edittxt2)
        val salary = findViewById<Spinner>(R.id.spiner1)
        val regin = findViewById<Spinner>(R.id.spiner2)


        submit.setOnClickListener(){
            var name = name.text.toString()
            var nic = nic.text.toString()
            var salary = salary.dropDownHorizontalOffset.toString()
            var regin = regin.dropDownHorizontalOffset.toString()


            val intent = Intent(this@MainActivity , interface1::class.java)
            intent.putExtra("name" , name)
            intent.putExtra("nic" , nic)
            intent.putExtra("salary", salary)
            intent.putExtra("regin", regin)
            startActivity(intent)
        }

        }
    }
