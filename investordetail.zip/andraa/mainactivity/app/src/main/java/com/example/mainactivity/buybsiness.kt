package com.example.mainactivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class buybsiness : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buybsiness)

        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        supportActionBar?.hide()


        val selctbttn2 = findViewById<Button>(R.id.selctbttn2);

        selctbttn2.setOnClickListener(){
            val intenta = Intent(this, interface3::class.java)
            startActivity(intenta)
            finish()
        }
    }
}