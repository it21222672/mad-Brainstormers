package com.example.mainactivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class interface1 : AppCompatActivity() {
    private fun onclick(any: Any) {

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_interface1)

        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        supportActionBar?.hide()

        var intent = intent
        val name = intent.getStringExtra("name")
        val nic = intent.getStringExtra("nic")
        val salary = intent.getStringExtra("salary")
        val regin = intent.getStringExtra("regin")
        val displyans = findViewById<TextView>(R.id.displyans)

        displyans.text = "name :" + name+"\nnic :" + nic+ "\nsalary :" + salary + "\nregin :"+ regin



        val bttndata = findViewById<Button>(R.id.displaybttn);

        bttndata.setOnClickListener(){
            val intenta = Intent(this, interface2::class.java)
            startActivity(intenta)
            finish()
        }





    }

}